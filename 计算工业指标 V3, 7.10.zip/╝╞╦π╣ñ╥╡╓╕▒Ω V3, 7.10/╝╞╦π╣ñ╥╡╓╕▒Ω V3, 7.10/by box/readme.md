此文档用于工业指标（BY BOX）判断

输入：merged ，gt

中间输出：filtered_predTag_1(取标记为1的pred)

最终输出： result_pre(以pred为标准，判断工业指标)，result_gt(以gt为标准)，probabilities(各指标占比)

